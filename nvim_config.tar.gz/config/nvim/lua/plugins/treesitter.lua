return {
    "nvim-treesitter/nvim-treesitter",
    name = "treesitter",
    build = ":TSUpdate",
    config = function()
        local configs = require("nvim-treesitter.configs")
        configs.setup({
            ensure_installed = {"lua", "python", "c", "cpp", "bash"},
            highlight = {
                 enable = true
            },
            indent = {
                enable = true
            }
        })
    end
}
