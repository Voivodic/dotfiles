return {
    {
        "mfussenegger/nvim-dap",
        name = "nvim-dap",
        config = function()
            local dap = require("dap")

            vim.keymap.set("n", "<Leader>b", dap.toggle_breakpoint, {})
            vim.keymap.set("n", "<Leader>c", dap.continue, {})
        end,
    },
    {
        "nvim-neotest/nvim-nio",
        name = "nvim-nio"
    },
    {
        "rcarriga/nvim-dap-ui",
        name = "dap-ui",
        config = function()
            local dap, dapui = require("dap"), require("dapui")
            dap.listeners.before.attach.dapui_config = function()
                dapui.open()
            end
            dap.listeners.before.launch.dapui_config = function()
                dapui.open()
            end
            dap.listeners.before.event_terminated.dapui_config = function()
                dapui.close()
            end
            dap.listeners.before.event_exited.dapui_config = function()
                dapui.close()
            end
        end
    }
}
