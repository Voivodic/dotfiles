import numpy as np

# Define the arrays
N = 1000
x = np.random.random(N)
y = np.random.random(N)

# Calculate the distance between each pair of points
distances = np.sqrt((x[np.newaxis, :] - x[:, np.newaxis])**2 + (y[np.newaxis, :] - y[:, np.newaxis])**2)

# Finde the closest points
closest_points = np.unravel_index(distances.argmin(), distances.shape)
